#include <linux/kernel.h>
#include <linux/linkage.h>

asmlinkage int sys_trash(void)
{
	return 0;
}
